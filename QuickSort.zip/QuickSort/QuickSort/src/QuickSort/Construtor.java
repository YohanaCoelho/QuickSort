package QuickSort;

import java.io.IOException;

public class Construtor {
    public static void main(String[] args) throws IOException {
        
        int[] vetor = {30, 20, 10, 40, 50, 60, 70, 80, 90, 100};

        Modelagem.quickSort(vetor, 0, vetor.length - 1);

        System.out.println("Vetor ordenado pelo QuickSort:");
        Visao.imprimirArray(vetor);

        int[] vetorInsertion = {30, 20, 10, 40, 50, 60, 70, 80, 90, 100};

        Modelagem.insertionSort(vetorInsertion);
        System.out.println("Vetor ordenado pelo InsertionSort:");
        Visao.imprimirArray(vetorInsertion);
    }
}
