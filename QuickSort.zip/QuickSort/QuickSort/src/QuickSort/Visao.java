package QuickSort;

public class Visao {
    public static void imprimirArray(int[] vetor) {
        for (int num : vetor) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
